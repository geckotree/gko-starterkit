//OBSOLETE! THIS IS LEGACY CODE AND WILL BE REMOVED IN FUTURE VERSIONS!

function resizePanel(PanelName, hasMenu, redoOnResize) {
    //DO NOTHING
}

function resizePanelTo(PanelName, hasMenu, pWidth, pHeight) {
    //DO NOTHING
}
