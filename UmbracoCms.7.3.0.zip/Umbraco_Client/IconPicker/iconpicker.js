﻿
//todo
function openIconPicker(element) {

}